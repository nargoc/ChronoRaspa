Reemplazo de imagenes del HOME (PNG)

Puedes cambiar las imagenes del menu principal sustituyendo estos ficheros PNG:

- quick.png   -> Rally rapido
- create.png  -> Crear nuevo Rally
- pilots.png  -> Pilotos
- tracks.png  -> Tracks
- history.png -> Historial

Notas:
1) La app intenta cargar primero PNG.
2) Si no existe, cae automaticamente al SVG de respaldo.

Ruta usada en index.html:
assets/home/<nombre>.png
